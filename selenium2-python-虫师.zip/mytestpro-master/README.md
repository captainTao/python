# mytestpro

介绍：
  本项目为《Selenium2 自动化测试实战---基于Python语言》一书中的例子
  它包含功能:
  * 第四章例子，对应webdriver_api目录
  * 第五章例子，对应test_model目录
  * 第七章例子，对应unittest_example目录
  * 最后项目实例，对应整个项目代码


Python版本与依赖库：
  * python3.5+ :https://www.python.org/
  * Selenium3.0+ :https://pypi.python.org/pypi/selenium


运行建议：
   所有例子在Chrome浏览器下运行通过，建议使用Chrome浏览器。
   Chromedriver(Chrome)驱动下载地址：https://sites.google.com/a/chromium.org/chromedriver/home


购买本书：
  http://item.jd.com/11858013.html
